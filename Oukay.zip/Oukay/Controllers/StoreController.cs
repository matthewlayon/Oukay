﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Oukay.Data;
using Oukay.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Oukay.Controllers
{
    public class StoreController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StoreController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var list = _context.Products.ToList();



            return View(list);
        }

        public IActionResult AddtoCart(int productId)
        {
            var cart = new List<Cart>();
            var product = _context.Products.Find(productId);
            cart.Add(new Cart()
            {
                Product = product
            }) ;

            var test = 1;

            _ = test;
          


            return RedirectToAction("Index");
        }
        //public IActionResult CategoryMenu()
        //{
        //    var categories = _context.Categories.ToList();
        //    return PartialView(categories);

        //}
        //public IActionResult Browse(string category)
        //{
        //    var categoryModel = _context.Categories.Include("Product")
        //        .Single(c => c.Name == category);
        //    return View(categoryModel);
        //}
        //public IActionResult Details(int id)
        //{
        //    var product = _context.Products.Find(id);
        //    return View(product);
        //}
    }
}
