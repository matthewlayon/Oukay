﻿using Microsoft.AspNetCore.Mvc;
using Oukay.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Oukay.Models
{
    public class ShoppingCart
    {
        //private readonly ApplicationDbContext _context;

        //public ShoppingCart(ApplicationDbContext context)
        //{
        //    _context = context;
        //}
        //string ShoppingCartId { get; set; }
        //public const string CartSessionKey = "CartId";
        //public static ShoppingCart GetCart(HttpContextBase context)
        //{
        //    var cart = new ShoppingCart();
        //    cart.ShoppingCartId = cart.GetCartId(context);
        //    return cart;
        //}

        //public static ShoppingCart GetCart(Controller controller)
        //{
        //    return GetCart(controller.HttpContext);
        //}
    }
}
