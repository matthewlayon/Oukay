﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Oukay.Models;
using Microsoft.AspNetCore.Mvc;

namespace Oukay.Models
{
    [Keyless]
    public class Cart
    {
       
        public virtual Product Product { get; set; }
    }
}
